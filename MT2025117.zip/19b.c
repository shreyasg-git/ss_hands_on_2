/*
============================================================================
Name : 19b.c
Author : Shreyas Gangurde
Description : 19. Create a FIFO file by
                b. mkfifo
Date: 23rd September 2025
============================================================================
*/

// mkfifo -m 0644 myfifo
