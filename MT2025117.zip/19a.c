/*
============================================================================
Name : 19a.c
Author : Shreyas Gangurde
Description : 19. Create a FIFO file by
                a. mknod command
Date: 23rd September 2025
============================================================================
*/

// > mknod myfifo p
